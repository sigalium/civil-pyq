# CivilPYQ — Project Context

Read this whole file before making any changes. It exists so a new conversation
can pick up exactly where the last one left off, without re-deriving decisions
that were already made (often the hard way).

## What this is

CivilPYQ is a free resource-sharing site for civil engineering students (GCU —
Girijananda Chowdhury University, Assam). It hosts previous-year question
papers (PYQs), lab manuals, syllabi, IS codes (Indian Standard codes), and an
academic calendar, organized by semester and subject. Anyone can browse and
download; a small set of admins manage content through a dashboard. Built and
run solo by "Tech" (Bastab), who is not a professional dev — explain
non-obvious decisions rather than assuming familiarity with a pattern.

Site is CivilPYQ, not to be confused with ShearFrame/ShearCAD/civil-pyq-pdf —
those are separate/related things mentioned only in passing earlier in this
project's life; this document only concerns CivilPYQ.

## Hosting and infra (all free tier, intentionally)

- **Frontend**: React + Vite, deployed on **Netlify**. Netlify only rebuilds
  on a push to the connected GitHub repo — local changes do nothing to the
  live site until pushed.
- **Backend**: **Supabase** (Postgres + Auth + Edge Functions + Storage).
  Free tier. The user has **no Docker, no Supabase CLI** — everything is done
  through the Supabase Studio SQL Editor and the Functions dashboard. Never
  suggest CLI-only workflows without an alternative.
- **File storage**: PDFs and images are **not** stored in Supabase Storage —
  they live in a **separate GitHub repo** (`civil-pyq-pdf`, owner `sigalium`),
  committed via the GitHub Contents API, and served publicly through
  **jsDelivr** (`cdn.jsdelivr.net/gh/{owner}/{repo}@{branch}/{path}`). This
  keeps bandwidth/storage costs at zero. `pending-uploads` is the one real
  Supabase Storage bucket, used only for unreviewed student submissions
  before an admin approves them into GitHub.
- Env vars (`.env`, never committed): `VITE_SUPABASE_URL`,
  `VITE_SUPABASE_ANON_KEY`, `VITE_JSDELIVR_OWNER`, `VITE_JSDELIVR_REPO`,
  `VITE_JSDELIVR_BRANCH`, `VITE_TURNSTILE_SITE_KEY`.
- GitHub repo layout for files: `pdfs/Semester{N}/{Subject}/...`,
  `pdfs/ISCodes/...`, `pdfs/Academic_Calendar.pdf`, `Contributor/...` for
  contributor photos and default avatars.

## Frontend structure

```
src/
  App.jsx                      routes, top-level providers/layout
  main.jsx                     provider nesting root
  context/
    AuthContext.jsx            Supabase auth + admin profile
    ResourcesDataContext.jsx   single source of truth: subjects, resources,
                                settings, IS codes — fetched once, cached
    ContributorsDataContext.jsx
    PDFWindowContext.jsx       floating PDF viewer window manager state
    ThemeContext.jsx
  pages/                       route-level pages (public site)
    Resources.jsx               semester -> subject -> PYQ/Lab/Syllabus
    IsCodes.jsx                  flat IS codes list, /resources/is-codes
    Dashboard.jsx                admin shell, tab switcher, routes to:
    pages/dashboard/*Tab.jsx     one file per dashboard tab (see below)
  components/                  shared UI: PDFViewer, Navbar, BackButton,
                                ConfirmModal, Select, ResourcesQuickNav, etc.
  utils/                       githubUpload.js, resourceOrdering.js,
                                pdfCompression.js, analytics.js, etc.
supabase/
  schema.sql                   AUTHORITATIVE full schema — see below
  migrations/*.sql              chronological migrations actually run live
  functions/                    edge functions (Deno)
```

### Dashboard tabs (`src/pages/dashboard/`)
`SubmissionsTab`, `ResourcesTab` (+ `IsCodesPanel.jsx` nested inside it),
`UploadTab` (bulk upload — **renamed from `BulkUploadTab`**, route is
`/dashboard/upload`), `MigrationTab`, `ContributorsTab`, `TrashTab`,
`MembersTab`, `AuditLogTab`, `AnalyticsTab`.

`ResourcesTab` has a route-based sub-view: visiting
`/dashboard/resources/is-codes` swaps its *entire* content for
`IsCodesPanel` with its own back button — it's not an inline expand/collapse
panel, it's a full view swap (this was explicitly requested after an earlier
version that just toggled a panel open/closed felt wrong).

## Reorder-by-position (`src/components/PositionInput.jsx`)

Every drag-to-reorder list in the dashboard (Resources tab's PYQ/Lab lists,
Contributors tab's Student/Faculty lists, Codes & Standards panel's
Sections list and per-section Codes lists) now shows a small numeric input
next to the drag handle, displaying the item's current 1-based position.
Typing a new number and blurring/pressing Enter moves the item there in the
local in-memory order, marks it dirty, and shows the same
`ReorderConfirmBar` (✓/✕) that drag-reordering already used — it's a second
way to trigger the same `persistOrder()` write, not a separate system.

Added specifically because the Resources tab's PYQ/Lab lists paginate at 5
items (`RESOURCE_PAGE_SIZE`) and Contributors paginates at 10
(`CONTRIBUTORS_PAGE_SIZE`) — drag-and-drop only works within a page, so
typing a target position was added as the way to move an item across pages.
When a typed position lands on a different page, the paginated lists
(`DraggableResourceList` in `ResourcesTab.jsx`, `PaginatedGroup` in
`ContributorsTab.jsx`) auto-jump to that page so the moved item and the
confirm bar are visible. The Codes & Standards panel's lists
(`SectionsManager`, `CodeGroup` in `CodesAndStandardsPanel.jsx`) aren't
paginated, so no page-jump is needed there — the input was still added for
consistency since a long Codes list benefits from it too, not because
pagination forced it.

`PositionInput` is a single shared component — don't recreate a local copy
in a dashboard tab; import it.

## Database schema — current state

**`schema.sql` is authoritative.** It was built by asking the user to run
introspection queries (`information_schema`, `pg_policies`, `pg_proc`,
`pg_get_functiondef`, etc.) against the *live* database and pasting results
back — not reconstructed from memory of migrations, because that drifts.
**Any time you change the schema, update `schema.sql` in the same batch —
do not treat it as an afterthought.** It has **zero comments** — the user
was explicit and repeated about this; if you ever add one, remove it.

### Tables
- `admins` — email (PK), username, role (`owner`/`admin`), a set of
  granular `can_*` boolean permission flags (`can_review_submissions`,
  `can_edit_resources`, `can_delete_resources`, `can_view_trash`,
  `can_view_audit_log`, `can_view_members`, `can_manage_contributors`,
  `can_edit_members`, `can_view_analytics`), `is_faculty`. Display label:
  `role='owner'` → **"Main Admin"** in UI (never show raw "owner"), then
  "Faculty Admin" (green badge) if `is_faculty`, else "Admin". See
  `src/utils/adminRoles.js` — single source of truth for these labels,
  used by both the account menu and Members tab. Don't duplicate this
  logic locally in a component again.
- `audit_log` — actor_email, action, table_name, record_id, details
  (jsonb), created_at. Populated by triggers, not app code.
- `contributors` — student/faculty contributor cards shown on the public
  site. `profile_pic` is either an uploaded GitHub path or one of the
  shared default avatars (served from jsDelivr, **not** duplicated in
  `/public` — those local copies were deleted as redundant).
- `global_resources` — flat key/value settings table. Keys in use:
  `academic_calendar_path`, `syllabus_semester_{N}` (central syllabus
  fallback per semester).
- `subjects` — semester, name, is_elective, sort_order, deleted_at.
- `resources` — the workhorse table. `resource_type` is
  `pyq` | `lab` | `syllabus` | `iscode`. `semester`/`subject` are
  **nullable** (IS codes don't belong to a subject).
  `linked_iscode_id` (self-referencing FK, nullable) — see IS Codes
  section below, this is important and has a history.
- `submissions` — student-submitted files awaiting review, stored in the
  `pending-uploads` Storage bucket until approved (then moved to GitHub
  and inserted into `resources`).
- `resource_events` — `resource_id` (FK → `resources.id`), `event_type`
  (`view`/`download`), `created_at`. Feeds Analytics. Logged client-side
  via `src/utils/analytics.js`, debounced 1 hour per resource+event type
  via localStorage so refresh-spam doesn't inflate counts. Fires
  regardless of whether Analytics is in demo mode — demo mode only
  affects the *read* side.

### IS Codes — architecture history, read this before touching it again

IS Codes went through a full round-trip in this project's history:
1. Started as `resources` rows with `resource_type='iscode'`
   (`semester`/`subject` null), plus `linked_iscode_id` on other rows to
   mark "this PYQ/Lab entry is actually a link to a central IS code."
2. Was refactored into two dedicated tables (`iscodes`, `iscode_links`)
   to fix a real bug: linking created a **duplicate row** with its own
   frozen `name`, so renaming the source IS code never propagated to
   places it was linked into.
3. **That refactor was reverted** back to design #1, because the new
   tables were deployed to the live database out of sync with the app
   code (a migration ran without the corresponding code, then vice versa),
   causing a production crash. The user explicitly asked to go back to
   the simpler single-table design rather than debug the sync issue
   under pressure.
4. **Current live state (as of the last migration,
   `20260902_revert_iscodes_to_resources.sql`): back to design #1.**
   `iscodes`/`iscode_links` tables were dropped; data was copied back
   into `resources` preserving original IDs.

**Known accepted limitation of the current design**: renaming a "linked"
IS code does not update the linked copy elsewhere (the original bug from
point 2 is back, on purpose, as a trade-off for stability). If this needs
fixing again, do NOT casually re-attempt the two-table refactor — if you
do, the migration and the app code deploy must be treated as one atomic
step from the user's perspective: confirm the migration succeeded (ask
them to check Table Editor, don't assume) *before* shipping code that
depends on it. Getting this sequencing wrong is exactly what caused the
crash and a "you corrupted my project" scare.

The `resources_resource_type_check` constraint must include `'iscode'`
for any of this to work — it was missing `'iscode'` for a while (a real
bug that caused silent insert failures + a UI that hung forever with no
error message, since the calling code had no try/catch). Fixed in
`20260831_fix_iscode_check_constraint.sql`, then briefly removed again by
the two-table refactor, then restored by the revert migration. Current
live state: included. If IS Code uploads ever silently hang again with no
error shown, **check this constraint first**.

### Functions (all in `schema.sql`, `security definer` where noted)
- `is_owner()`, `can_view_members_list()`, `can_edit_members_list()` —
  permission check helpers used in RLS policies. `security definer`,
  execute revoked from `public`/`anon`, granted to `authenticated` only.
- `purge_expired_trash()` — deletes soft-deleted rows older than 30 days
  across resources/subjects/contributors. Runs as `service_role` only
  (should be called by a scheduled job/cron, not from the app).
- `log_audit_event()`, `log_admin_audit_event()`,
  `log_settings_audit_event()` — trigger functions writing to
  `audit_log`. Trigger functions can't be invoked directly by Postgres
  design, so the "Public Can Execute" advisor warning on these is mostly
  cosmetic, but access was still locked down for cleanliness.
- `enforce_resources_update_permission()`,
  `enforce_subjects_update_permission()` — `before update` triggers that
  check the caller's permissions and reject unauthorized edits vs.
  trash/restore-only changes differently. **Important**: both start with
  `if auth.email() is null then return new; end if;` — this exists
  specifically so that **service-role calls** (edge functions, e.g. the
  file-size backfill) bypass the permission check entirely, since
  `auth.email()` is null in that context and the trigger would otherwise
  wrongly classify a metadata-only update (like setting
  `file_size_bytes`) as an unauthorized "trash/restore" attempt requiring
  `can_delete_resources`. If you ever add a new backend-driven bulk
  update, this is the pattern to be aware of.
- `resource_leaderboard(sort_by, limit_count)`,
  `resource_event_trend(days_back)`, `resource_storage_breakdown()`,
  `analytics_summary()` — power the Analytics tab. All read-only,
  `stable`, granted to `authenticated` only.

### RLS pattern used throughout
Almost every table follows: public can `select` rows where
`deleted_at is null`; `authenticated` staff (anyone with an `admins` row)
can select all including trashed; specific `can_*` permission flags gate
insert/update; only `role='owner'` can hard-delete. Match this pattern
for any new table rather than inventing a new shape.

### Storage bucket
`pending-uploads` (private). Policies gate insert/select/update/delete on
`can_review_submissions` or owner.

## Edge functions (`supabase/functions/`)

- `github-upload` — commits a file to the GitHub repo via the Contents
  API, returns the jsDelivr URL. Fires a jsDelivr cache-purge request
  **without awaiting it fully** (has a 4s timeout via `AbortSignal`) —
  this was a real bug: the original version `await`ed the purge with no
  timeout, and if jsDelivr was slow, the whole upload appeared to hang
  for minutes even though the GitHub commit had already succeeded.
- `github-delete` — the counterpart, added later after discovering that
  "permanently delete" in the Trash tab only ever deleted the database
  row and left the actual file sitting in GitHub forever. Fetches the
  file's current SHA, then issues a real GitHub delete. Owner-only.
- `backfill-file-sizes` — one-time-use function to populate
  `file_size_bytes` for resources uploaded before that column existed, by
  looking up each file's size via the GitHub Contents API
  (`?ref={branch}` — an earlier version omitted this and 404'd on every
  single file because it queried the wrong branch by default).
- `migrate-file` — used by the Migration tab to reassign a resource's
  subject/semester (moves the GitHub file to a new path).
- `scan-file`, `submit-resource` — part of the public submission flow
  (student uploads → malware scan → lands in `pending-uploads` →
  admin reviews in Submissions tab).

All edge functions that need to bypass the browser's CORS preflight
(which never carries an `Authorization` header) should set
`verify_jwt = false` in `supabase/config.toml` for that function and do
their own auth check via `supabase.auth.getUser(token)` inside the
function body — this is already the pattern for the newer functions;
don't rely on Supabase's platform-level JWT gate for functions that need
to work from a browser call, it rejects the preflight before your code
even runs.

## Key conventions and things the user has repeated multiple times

- **No code comments, anywhere.** Not in JS/JSX, not in SQL. This has
  been said more than once with real frustration when violated — check
  before delivering.
- **Deliver complete files/projects, not diffs**, when packaging zips for
  the user to apply locally. Early in this project, incremental
  "only-changed-files" zips caused real data-loss panic when the user
  applied one out of sequence over a reset local copy. **Always package
  the full current project state** (`src/`, `supabase/`, `package.json`,
  excluding `node_modules`, `.git`, `.env`, `src/assets/`) rather than
  just the files touched in the latest turn, unless explicitly told
  otherwise.
- **Any schema change ships with an updated `schema.sql` in the same
  batch.** The user has asked for this explicitly and it should not need
  re-asking.
- UI consistency is a recurring pain point: button alignment, click
  target size (a `<button>` in a `flex-direction: column` parent
  stretches to full width by default via `align-items: stretch` unless
  given `align-self: flex-start` — this exact bug recurred across
  multiple back-button implementations before being fixed once at the
  shared `BackButton` component level), file-count/action-button
  alignment in list rows (fix: give the trailing action group its own
  `margin-left: auto` so it's right-aligned whether or not it wraps to
  its own line), and mobile-specific `flex-basis` values that
  accidentally become height constraints once `flex-direction` switches
  to `column` on narrow screens (watch for `flex: 1 1 320px` style rules
  that were written assuming a horizontal layout).
- Confirmation dialogs: **never use `window.confirm()`** — there's a
  shared `src/components/ConfirmModal.jsx` (matches the existing
  `SignOutConfirmModal` visual style) for this. All prior
  `window.confirm()` call sites across the app were converted to it.
- The user is not a professional developer. Explain *why*, not just
  *what*, especially for anything Supabase/Postgres/RLS-related.
- The user has no Docker/CLI access to Supabase — all schema changes are
  delivered as `.sql` files to paste into the SQL Editor, one migration
  at a time, in the stated order.
- IS Codes, PDF viewer sharing (`?open=` query param using resource
  UUIDs, never filenames), the mobile quick-nav drawer, and PDF
  compression are all real, deliberately-built features — not
  incidental. See the PDF Viewer section below before changing viewer
  behavior.

## PDF Viewer (`src/components/PDFViewer.jsx`)

Floating/windowed viewer (`PDFWindowContext` + `PDFWindowManager` manage
multiple open windows). Header: minimize (desktop only) / fullscreen
(Lucide `Maximize2`/`Minimize2`, not MUI) / close. Bottom bar: zoom
out/in, Download (opens the jsDelivr URL in a new tab — it's a
cross-origin link so the old `<a download>` trick never actually forced
a download anyway), Share (icon-only, copies the current shareable URL,
shows a "Link copied" toast using the same fade-in/out indicator style
as the page-number badge — not a button label change).

**Shareable links**: implemented via `src/components/PDFUrlSync.jsx`,
mounted once at the app root. Syncs a `?open=<uuid>,<uuid>,...` query
param (resource IDs, deliberately not filenames) to reflect currently
open PDF windows, and restores them on page load. Two bugs already found
and fixed here, worth knowing about if this breaks again:
1. The write-back effect ran on mount with an empty window list and
   wiped the `?open=` param before the async restore effect got a chance
   to read it — fixed by gating the write effect behind a
   "restoration has been attempted" flag.
2. On mobile, only the first ID in the list is restored (no multi-window
   support there).

## Compression (`src/utils/pdfCompression.js`,
`src/components/PDFCompressionModal.jsx`)

Client-side only: renders each page via `pdf.js` to a canvas, re-encodes
as JPEG at one of three DPI/quality presets, rebuilds via `pdf-lib`. This
is a **rasterize approach** — it does not touch embedded images
selectively, it flattens every page into an image. Real, accepted
limitation: **this can make small text-heavy PDFs (like a lecture
syllabus) larger, not smaller**, since vector text is often more
byte-efficient than any rasterized version. The modal shows a live
Original/Compressed side-by-side preview (via an embedded scrollable
`react-pdf` viewer, not a static screenshot — an earlier version showed
only a single-page static image, which the user rightly rejected as
useless for judging quality) and warns explicitly when the result would
be larger than the original. Default preset is "High compression" since
it's most likely to actually shrink borderline files. Compression state
(`originalFile` vs `compressedFile`) is tracked separately per staged
entry so reopening the compressor after applying once doesn't
double-compress an already-compressed file.

## Analytics tab

Reads from the SQL functions listed above. Has a demo-data mode:
`src/config/analyticsDemo.json` (`{"demo": true}`) shows realistic fake
data from `src/utils/analyticsDemoData.js` so the charts can be visually
tuned before real traffic exists — flip to `false` once there's real
data to show. This only affects the *read* side; event logging always
writes real rows regardless of the flag.

## Recent file renames / structural moves (so old names don't confuse a search)

- `BulkUploadTab.jsx` → `UploadTab.jsx` (component renamed too,
  `BulkUploadTab` → `UploadTab`). Route slug `/dashboard/bulk-upload` →
  `/dashboard/upload`.
- `scripts/` folder (two unused one-off migration scripts,
  `migrate-contributors.mjs` and `migrate-resources.mjs`) was deleted —
  don't recreate it without reason.
- `public/Contributor/Default/*` (12 duplicate default avatar images) was
  deleted — defaults are served from jsDelivr only now, not bundled
  locally.

## What to ask the user for, rather than guess

- The exact current state of any table/policy/function before writing a
  migration that assumes a particular starting point — this project has
  been bitten twice by assuming a prior migration ran when it hadn't (or
  had run further than expected). When in doubt, give them a short
  `select`/`pg_get_constraintdef`/`information_schema` query to run and
  paste back, the same way `schema.sql` itself was built.
- Whether they're looking at `localhost` (local dev server) or the live
  Netlify site when something "isn't showing up" — these are genuinely
  different states and this has caused confusion before (local files
  being fully correct while the live site still ran an old deployed
  build, or a dev server needing a restart).
