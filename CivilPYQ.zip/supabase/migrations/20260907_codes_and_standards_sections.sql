create table if not exists public.sections (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  sort_order integer not null default 0,
  deleted_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.resources add column if not exists section_id uuid references public.sections(id) on delete set null;

create index if not exists resources_section_idx on public.resources(section_id);

alter table public.sections enable row level security;

drop policy if exists "public can read active sections" on public.sections;
drop policy if exists "staff can read all sections" on public.sections;
drop policy if exists "editors can insert sections" on public.sections;
drop policy if exists "editors can update sections" on public.sections;
drop policy if exists "owner can hard delete sections" on public.sections;

create policy "public can read active sections" on public.sections for select to public using (deleted_at is null);
create policy "staff can read all sections" on public.sections for select to authenticated using (
  exists (select 1 from admins a where a.email = auth.email())
);
create policy "editors can insert sections" on public.sections for insert to authenticated with check (
  exists (select 1 from admins a where a.email = auth.email() and (a.role = 'owner' or a.can_edit_resources))
);
create policy "editors can update sections" on public.sections for update to authenticated using (
  exists (select 1 from admins a where a.email = auth.email() and (a.role = 'owner' or a.can_edit_resources or a.can_delete_resources))
) with check (
  exists (select 1 from admins a where a.email = auth.email() and (a.role = 'owner' or a.can_edit_resources or a.can_delete_resources))
);
create policy "owner can hard delete sections" on public.sections for delete to authenticated using (
  exists (select 1 from admins a where a.email = auth.email() and a.role = 'owner')
);

drop trigger if exists trg_sections_audit on public.sections;
create trigger trg_sections_audit after insert or update or delete on public.sections
  for each row execute function log_audit_event();
