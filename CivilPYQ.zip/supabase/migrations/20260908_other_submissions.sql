alter table public.submissions alter column semester drop not null;
alter table public.submissions alter column subject drop not null;

alter table public.submissions drop constraint if exists submissions_resource_type_check;
alter table public.submissions add constraint submissions_resource_type_check
  check (resource_type = any (array['pyq', 'lab', 'syllabus', 'semester_syllabus', 'other']));
