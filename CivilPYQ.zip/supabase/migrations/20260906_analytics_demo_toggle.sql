alter table public.admins add column if not exists can_manage_settings boolean not null default false;

drop policy if exists "editors can upsert site settings" on public.global_resources;
drop policy if exists "editors can update site settings" on public.global_resources;

create policy "editors can upsert site settings"
on public.global_resources
for insert
with check (
  exists (
    select 1 from admins a
    where a.email = auth.email()
    and (
      a.role = 'owner'
      or (a.can_edit_resources and key <> 'analytics_demo_mode')
    )
  )
);

create policy "editors can update site settings"
on public.global_resources
for update
using (
  exists (
    select 1 from admins a
    where a.email = auth.email()
    and (
      a.role = 'owner'
      or (a.can_edit_resources and key <> 'analytics_demo_mode')
    )
  )
)
with check (
  exists (
    select 1 from admins a
    where a.email = auth.email()
    and (
      a.role = 'owner'
      or (a.can_edit_resources and key <> 'analytics_demo_mode')
    )
  )
);

insert into public.global_resources (key, value)
values ('analytics_demo_mode', 'true')
on conflict (key) do nothing;
