drop policy if exists "editors can upsert site settings" on public.global_resources;
drop policy if exists "editors can update site settings" on public.global_resources;

create policy "editors can upsert site settings"
on public.global_resources
for insert
with check (
  exists (
    select 1 from admins a
    where a.email = auth.email()
    and (
      a.role = 'owner'
      or (a.is_developer and key in ('maintenance_mode', 'maintenance_until', 'maintenance_message', 'maintenance_auto_off'))
      or (a.can_manage_settings and key = 'submission_intake_enabled')
      or (a.can_edit_resources and key not in ('analytics_demo_mode', 'maintenance_mode', 'maintenance_until', 'maintenance_message', 'maintenance_auto_off', 'submission_intake_enabled'))
    )
  )
);

create policy "editors can update site settings"
on public.global_resources
for update
using (
  exists (
    select 1 from admins a
    where a.email = auth.email()
    and (
      a.role = 'owner'
      or (a.is_developer and key in ('maintenance_mode', 'maintenance_until', 'maintenance_message', 'maintenance_auto_off'))
      or (a.can_manage_settings and key = 'submission_intake_enabled')
      or (a.can_edit_resources and key not in ('analytics_demo_mode', 'maintenance_mode', 'maintenance_until', 'maintenance_message', 'maintenance_auto_off', 'submission_intake_enabled'))
    )
  )
)
with check (
  exists (
    select 1 from admins a
    where a.email = auth.email()
    and (
      a.role = 'owner'
      or (a.is_developer and key in ('maintenance_mode', 'maintenance_until', 'maintenance_message', 'maintenance_auto_off'))
      or (a.can_manage_settings and key = 'submission_intake_enabled')
      or (a.can_edit_resources and key not in ('analytics_demo_mode', 'maintenance_mode', 'maintenance_until', 'maintenance_message', 'maintenance_auto_off', 'submission_intake_enabled'))
    )
  )
);

insert into public.global_resources (key, value) values
  ('maintenance_auto_off', 'false')
on conflict (key) do nothing;
