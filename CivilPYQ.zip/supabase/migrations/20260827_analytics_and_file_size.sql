alter table resources add column if not exists file_size_bytes bigint;
alter table submissions add column if not exists file_size_bytes bigint;
alter table admins add column if not exists can_view_analytics boolean not null default false;

create table if not exists resource_events (
  id bigint generated always as identity primary key,
  resource_id uuid not null references resources(id) on delete cascade,
  event_type text not null check (event_type in ('view', 'download')),
  created_at timestamptz not null default now()
);

create index if not exists resource_events_resource_id_idx on resource_events(resource_id);
create index if not exists resource_events_created_at_idx on resource_events(created_at);
create index if not exists resource_events_type_idx on resource_events(event_type);

alter table resource_events enable row level security;

drop policy if exists "public can log resource events" on resource_events;
create policy "public can log resource events"
on resource_events for insert
to public
with check (event_type in ('view', 'download'));

drop policy if exists "analytics viewers can read events" on resource_events;
create policy "analytics viewers can read events"
on resource_events for select
to authenticated
using (
  exists (
    select 1 from admins a
    where a.email = auth.email()
      and (a.role = 'owner' or a.can_view_analytics)
  )
);

create or replace function resource_leaderboard(sort_by text default 'views', limit_count integer default 10)
returns table (
  resource_id uuid,
  name text,
  subject text,
  semester integer,
  resource_type text,
  view_count bigint,
  download_count bigint,
  file_size_bytes bigint
)
language sql stable as $$
  select
    r.id,
    r.name,
    r.subject,
    r.semester,
    r.resource_type,
    coalesce(v.cnt, 0),
    coalesce(d.cnt, 0),
    r.file_size_bytes
  from resources r
  left join (
    select resource_id, count(*) cnt from resource_events where event_type = 'view' group by resource_id
  ) v on v.resource_id = r.id
  left join (
    select resource_id, count(*) cnt from resource_events where event_type = 'download' group by resource_id
  ) d on d.resource_id = r.id
  where r.deleted_at is null
  order by case when sort_by = 'downloads' then coalesce(d.cnt, 0) else coalesce(v.cnt, 0) end desc
  limit limit_count;
$$;

create or replace function resource_event_trend(days_back integer default 30)
returns table (day date, views bigint, downloads bigint)
language sql stable as $$
  select
    d::date as day,
    coalesce(sum(case when e.event_type = 'view' then 1 else 0 end), 0) as views,
    coalesce(sum(case when e.event_type = 'download' then 1 else 0 end), 0) as downloads
  from generate_series(current_date - (days_back - 1), current_date, interval '1 day') d
  left join resource_events e on e.created_at::date = d::date
  group by d
  order by d;
$$;

create or replace function resource_storage_breakdown()
returns table (resource_type text, total_bytes bigint, file_count bigint)
language sql stable as $$
  select resource_type, coalesce(sum(file_size_bytes), 0), count(*)
  from resources
  where deleted_at is null
  group by resource_type;
$$;

create or replace function analytics_summary()
returns table (
  total_resources bigint,
  total_storage_bytes bigint,
  total_views bigint,
  total_downloads bigint,
  avg_file_size_bytes numeric
)
language sql stable as $$
  select
    (select count(*) from resources where deleted_at is null),
    (select coalesce(sum(file_size_bytes), 0) from resources where deleted_at is null),
    (select count(*) from resource_events where event_type = 'view'),
    (select count(*) from resource_events where event_type = 'download'),
    (select coalesce(avg(file_size_bytes), 0) from resources where deleted_at is null and file_size_bytes is not null);
$$;

revoke execute on function resource_leaderboard(text, integer) from public, anon;
revoke execute on function resource_event_trend(integer) from public, anon;
revoke execute on function resource_storage_breakdown() from public, anon;
revoke execute on function analytics_summary() from public, anon;
grant execute on function resource_leaderboard(text, integer) to authenticated;
grant execute on function resource_event_trend(integer) to authenticated;
grant execute on function resource_storage_breakdown() to authenticated;
grant execute on function analytics_summary() to authenticated;
