alter table resources alter column semester drop not null;
alter table resources alter column subject drop not null;
alter table resources add column if not exists linked_iscode_id uuid references resources(id) on delete set null;

create index if not exists resources_resource_type_idx on resources(resource_type) where deleted_at is null;
create index if not exists resources_linked_iscode_id_idx on resources(linked_iscode_id) where linked_iscode_id is not null;
