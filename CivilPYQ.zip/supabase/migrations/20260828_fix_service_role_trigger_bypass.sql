create or replace function public.enforce_resources_update_permission()
returns trigger
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  is_owner boolean;
  can_edit boolean;
  can_delete boolean;
  only_trash_change boolean;
begin
  if auth.email() is null then
    return new;
  end if;

  select (a.role = 'owner'), a.can_edit_resources, a.can_delete_resources
    into is_owner, can_edit, can_delete
  from admins a where a.email = auth.email();

  if coalesce(is_owner, false) then
    return new;
  end if;

  only_trash_change := (
    new.semester is not distinct from old.semester and
    new.subject is not distinct from old.subject and
    new.resource_type is not distinct from old.resource_type and
    new.name is not distinct from old.name and
    new.path is not distinct from old.path and
    new.sort_order is not distinct from old.sort_order
  );

  if only_trash_change then
    if coalesce(can_delete, false) then
      return new;
    end if;
    raise exception 'not permitted: trash/restore requires can_delete_resources';
  else
    if coalesce(can_edit, false) then
      return new;
    end if;
    raise exception 'not permitted: editing requires can_edit_resources';
  end if;
end;
$function$;

create or replace function public.enforce_subjects_update_permission()
returns trigger
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  is_owner boolean;
  can_edit boolean;
  can_delete boolean;
  only_trash_change boolean;
begin
  if auth.email() is null then
    return new;
  end if;

  select (a.role = 'owner'), a.can_edit_resources, a.can_delete_resources
    into is_owner, can_edit, can_delete
  from admins a where a.email = auth.email();

  if coalesce(is_owner, false) then
    return new;
  end if;

  only_trash_change := (
    new.semester is not distinct from old.semester and
    new.name is not distinct from old.name and
    new.is_elective is not distinct from old.is_elective and
    new.sort_order is not distinct from old.sort_order
  );

  if only_trash_change then
    if coalesce(can_delete, false) then
      return new;
    end if;
    raise exception 'not permitted: trash/restore requires can_delete_resources';
  else
    if coalesce(can_edit, false) then
      return new;
    end if;
    raise exception 'not permitted: editing requires can_edit_resources';
  end if;
end;
$function$;
