alter table public.admins add column if not exists is_developer boolean not null default false;

drop policy if exists "editors can upsert site settings" on public.global_resources;
drop policy if exists "editors can update site settings" on public.global_resources;

create policy "editors can upsert site settings"
on public.global_resources
for insert
with check (
  exists (
    select 1 from admins a
    where a.email = auth.email()
    and (
      a.role = 'owner'
      or (a.is_developer and key in ('maintenance_mode', 'maintenance_until', 'maintenance_message'))
      or (a.can_manage_settings and key = 'submission_intake_enabled')
      or (a.can_edit_resources and key not in ('analytics_demo_mode', 'maintenance_mode', 'maintenance_until', 'maintenance_message', 'submission_intake_enabled'))
    )
  )
);

create policy "editors can update site settings"
on public.global_resources
for update
using (
  exists (
    select 1 from admins a
    where a.email = auth.email()
    and (
      a.role = 'owner'
      or (a.is_developer and key in ('maintenance_mode', 'maintenance_until', 'maintenance_message'))
      or (a.can_manage_settings and key = 'submission_intake_enabled')
      or (a.can_edit_resources and key not in ('analytics_demo_mode', 'maintenance_mode', 'maintenance_until', 'maintenance_message', 'submission_intake_enabled'))
    )
  )
)
with check (
  exists (
    select 1 from admins a
    where a.email = auth.email()
    and (
      a.role = 'owner'
      or (a.is_developer and key in ('maintenance_mode', 'maintenance_until', 'maintenance_message'))
      or (a.can_manage_settings and key = 'submission_intake_enabled')
      or (a.can_edit_resources and key not in ('analytics_demo_mode', 'maintenance_mode', 'maintenance_until', 'maintenance_message', 'submission_intake_enabled'))
    )
  )
);

insert into public.global_resources (key, value) values
  ('maintenance_mode', 'false'),
  ('submission_intake_enabled', 'true')
on conflict (key) do nothing;

drop function if exists public.resource_leaderboard(text, integer);

create or replace function public.resource_leaderboard(sort_by text default 'views', limit_count integer default 10, type_filter text default null, days_back integer default null)
returns table (
  resource_id uuid,
  name text,
  subject text,
  semester integer,
  resource_type text,
  view_count bigint,
  download_count bigint,
  file_size_bytes bigint
)
language sql
stable
as $function$
  select
    r.id,
    r.name,
    r.subject,
    r.semester,
    r.resource_type,
    coalesce(v.cnt, 0),
    coalesce(d.cnt, 0),
    r.file_size_bytes
  from resources r
  left join (
    select resource_id, count(*) cnt from resource_events
    where event_type = 'view'
    and (days_back is null or created_at >= now() - (days_back || ' days')::interval)
    group by resource_id
  ) v on v.resource_id = r.id
  left join (
    select resource_id, count(*) cnt from resource_events
    where event_type = 'download'
    and (days_back is null or created_at >= now() - (days_back || ' days')::interval)
    group by resource_id
  ) d on d.resource_id = r.id
  where r.deleted_at is null
  and (type_filter is null or r.resource_type = type_filter)
  order by case when sort_by = 'downloads' then coalesce(d.cnt, 0) else coalesce(v.cnt, 0) end desc
  limit limit_count;
$function$;

revoke execute on function resource_leaderboard(text, integer, text, integer) from public, anon;
grant execute on function resource_leaderboard(text, integer, text, integer) to authenticated;
