revoke execute on function public.purge_expired_trash() from public, authenticated, anon;
grant execute on function public.purge_expired_trash() to service_role;

revoke execute on function public.can_view_members_list() from public, anon;
revoke execute on function public.can_edit_members_list() from public, anon;
revoke execute on function public.is_owner() from public, anon;
grant execute on function public.can_view_members_list() to authenticated;
grant execute on function public.can_edit_members_list() to authenticated;
grant execute on function public.is_owner() to authenticated;

revoke execute on function public.log_audit_event() from public, anon;
revoke execute on function public.log_admin_audit_event() from public, anon;
revoke execute on function public.log_settings_audit_event() from public, anon;
revoke execute on function public.enforce_subjects_update_permission() from public, anon;
revoke execute on function public.enforce_resources_update_permission() from public, anon;

drop policy if exists "reviewers can upload pending files" on storage.objects;
create policy "reviewers can upload pending files"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'pending-uploads'
  and exists (
    select 1 from admins a
    where a.email = auth.email()
      and (a.role = 'owner' or a.can_review_submissions)
  )
);

drop policy if exists "reviewers can overwrite pending files" on storage.objects;
create policy "reviewers can overwrite pending files"
on storage.objects for update
to authenticated
using (
  bucket_id = 'pending-uploads'
  and exists (
    select 1 from admins a
    where a.email = auth.email()
      and (a.role = 'owner' or a.can_review_submissions)
  )
)
with check (
  bucket_id = 'pending-uploads'
  and exists (
    select 1 from admins a
    where a.email = auth.email()
      and (a.role = 'owner' or a.can_review_submissions)
  )
);
