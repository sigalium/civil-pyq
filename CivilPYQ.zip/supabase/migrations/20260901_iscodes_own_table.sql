create table iscodes (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  path text not null,
  file_size_bytes bigint,
  sort_order integer not null default 0,
  deleted_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table iscode_links (
  id uuid primary key default gen_random_uuid(),
  iscode_id uuid not null references iscodes(id) on delete cascade,
  semester integer not null,
  subject text not null,
  resource_type text not null check (resource_type = any (array['pyq', 'lab'])),
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  unique (iscode_id, semester, subject, resource_type)
);

create index iscodes_deleted_at_idx on iscodes(deleted_at);
create index iscode_links_iscode_id_idx on iscode_links(iscode_id);
create index iscode_links_subject_semester_idx on iscode_links(semester, subject, resource_type);

insert into iscodes (id, name, path, file_size_bytes, sort_order, created_at)
select id, name, path, file_size_bytes, sort_order, created_at
from resources
where resource_type = 'iscode' and deleted_at is null;

insert into iscode_links (iscode_id, semester, subject, resource_type, sort_order, created_at)
select linked_iscode_id, semester, subject, resource_type, sort_order, created_at
from resources
where linked_iscode_id is not null and deleted_at is null
on conflict (iscode_id, semester, subject, resource_type) do nothing;

delete from resources where resource_type = 'iscode' or linked_iscode_id is not null;

alter table resources drop column linked_iscode_id;

alter table resources drop constraint resources_resource_type_check;
alter table resources add constraint resources_resource_type_check
  check (resource_type = any (array['pyq', 'lab', 'syllabus']));

alter table resource_events drop constraint resource_events_resource_id_fkey;

alter table iscodes enable row level security;
alter table iscode_links enable row level security;

create policy "public can read active iscodes" on iscodes for select to public using (deleted_at is null);
create policy "staff can read all iscodes" on iscodes for select to authenticated using (
  exists (select 1 from admins a where a.email = auth.email())
);
create policy "editors can insert iscodes" on iscodes for insert to authenticated with check (
  exists (select 1 from admins a where a.email = auth.email() and (a.role = 'owner' or a.can_edit_resources))
);
create policy "staff can update iscodes" on iscodes for update to authenticated using (
  exists (select 1 from admins a where a.email = auth.email())
) with check (
  exists (select 1 from admins a where a.email = auth.email())
);
create policy "owner can hard delete iscodes" on iscodes for delete to authenticated using (
  exists (select 1 from admins a where a.email = auth.email() and a.role = 'owner')
);

create policy "public can read iscode links" on iscode_links for select to public using (true);
create policy "editors can insert iscode links" on iscode_links for insert to authenticated with check (
  exists (select 1 from admins a where a.email = auth.email() and (a.role = 'owner' or a.can_edit_resources))
);
create policy "editors can delete iscode links" on iscode_links for delete to authenticated using (
  exists (select 1 from admins a where a.email = auth.email() and (a.role = 'owner' or a.can_edit_resources))
);
