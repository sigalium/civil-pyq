alter table resources drop constraint resources_resource_type_check;
alter table resources add constraint resources_resource_type_check
  check (resource_type = any (array['pyq', 'lab', 'syllabus', 'iscode']));
